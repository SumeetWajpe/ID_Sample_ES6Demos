import * as mathLib from 'Add';


console.log(mathLib);

