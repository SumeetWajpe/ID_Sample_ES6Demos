function Addition (x,y) {
	return x + y;
}

function Subtract (x,y) {
	return x - y;
}

const PI = 3.14;

export Addition;
export Subtract;